<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width,initial-scale=1">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <link rel="stylesheet" href="/public/css/reset.css" type="text/css">
        <link rel="stylesheet" href="/public/css/sucesso/sucesso.css" type="text/css">
        <title>Success</title>
        <link rel="icon" href="/public/img/icon.png">

    </head>
    <body>
        
        <div class="topo">
            
            <figure class="container-img">
                <a href="<?php echo APP_HOST; ?>/indexEn">
                    <img class="img-topo" src="/public/img/ouroLogoMenor.png" alt="Logo do site">
                </a>
            </figure>   
    
            <aside class="btn-menu">
                <p> Menu</p>
            </aside>

        </div>

        <aside class= "menu-escondido">

            <nav class="menu-escondido-links">
                <ul>
                    <li> <a href="<?php echo APP_HOST; ?>/indexEn"> Home page </a> </li>
                </ul>
                <ul>
                    <li> <a href="<?php echo APP_HOST; ?>/resume"> Résumé </a> </li>
                </ul>
                 <ul>
                     <li><a href="<?php echo APP_HOST; ?>/contact"> Contact </a></li>
                </ul>
                <ul>
                    <li><a href="<?php echo APP_HOST; ?>/projects/listing_professionla_projects">Professional projects</a></li>
                </ul>
                <ul>
                    <li><a href="<?php echo APP_HOST; ?>/projects/listing_personal_projects"> Personal projects </a></li>
                </ul>
            </nav>

        </aside>

        <div class="div-body">

            <main class="conteudo-principal">
                
                <div class="organiza-incluir-excluir-projetos">

                    <section class="incluir-projetos">

                        <form action="" method="" class="form-projetos" >
                            
                            <div>
                                <p> Your form was sent correctly!</p>
                                
                            </div>

                            <a id="voltar-btn" href="<?php echo APP_HOST; ?>/contact">Contact page</a>
    
                        </form>
    
                    </section>

                </div>           
            </main>

        <footer class="footer-todo">

            <div class="p-footer">
                <p>Created by Luiz Marques.</p> 
            </div>
            <div class="links-footer">
                <a href="https://github.com/luizfsmarques" target="blank">
                    <img src="/public/img/github.png" alt="Link para site github">
                    
                </a>
                <a href="https://www.linkedin.com/in/luiz-fernando-serra-marques-50b21417b/" target="blank">
                    <img src="/public/img/linkedin.png" alt="Link para site linkedin">
                   
                </a>
            </div>     

        </footer>

         <script src="/public/js/mostraMenu.js"></script>
         <script src="/public/js/alteracaoProjetos.js"></script>

    </body>
</html>
