<!DOCTYPE html>
<html lang="pt-br">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width,initial-scale=1">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <link rel="stylesheet" href="/public/css/reset.css" type="text/css">
        <link rel="stylesheet" href="/public/css/projetospes3.css" type="text/css">
        <title>Projetos pessoais</title>
        <link rel="icon" href="/public/img/icon.png">

        <?php

            // Se existir sessão, ela é apagada!
            if( (isset($_SESSION['user'])==true ) && (isset($_SESSION['password'])==true))
            {
                unset($_SESSION['user']);
                unset($_SESSION['password']);
                header("Location:" . APP_HOST . "/projetos");
            }
        ?>

    </head>
    <body>
        
        
        <div class="topo">
            
            <figure class="container-img">
                <a href="<?php echo APP_HOST; ?>/index">
                    <img class="img-topo" src="/public/img/ouroLogoMenor.png" alt="Logo do site">
                </a>
            </figure>   
    
            <aside class="btn-menu">
                <p> Menu</p>
            </aside>

        </div>

        <aside class= "menu-escondido">

        <nav class="menu-escondido-links">
                <ul>
                    <li> <a href="<?php echo APP_HOST; ?>/index"> Página inicial </a> </li>
                </ul>
                <ul>
                    <li> <a href="<?php echo APP_HOST; ?>/curriculo"> Currículo </a> </li>
                </ul>
                 <ul>
                     <li><a href="<?php echo APP_HOST; ?>/contato"> Contato </a></li>
                </ul>
                <ul>
                    <li><a href="<?php echo APP_HOST; ?>/projetos/listagem_projetos_profissionais">Projetos profissionais</a></li>
                </ul>
                <ul>
                    <li><a href="<?php echo APP_HOST; ?>/projetos/listagem_projetos_pessoais"> Projetos pessoais </a></li>
                </ul>
            </nav>

        </aside>

        <div class="div-body">

            <h1 class="titulo-principal">Projetos pessoais</h1>

                <main class="conteudo-principal">
                    
                    <?php

                        if(!count($viewVar))
                        {
                            echo "Não existe projetos!";
                        }else
                        {   
                            foreach($viewVar['projetos'] as $projetos)
                            {
                    ?>          <?php
                                if($projetos->getTipo() == "pessoal")
                                {
                                ?>
                                    <section class="card">
                                        <div class="imagem-box">
                                            <img class="imagem" src="/public/img/projetos/<?php echo $projetos->getImagem(); ?>">
                                        </div>
                                        <div class="informacao-box">
                                            <p class="nome-projeto">Nome: <?php echo $projetos->getNome();?> </p>
                                            <p class="tecnologia">Tecnologias: <?php echo $projetos->getTecnologia(); ?> </p>
                                            <p class="descricao">Descrição: <?php echo $projetos->getDescricao();?> </p>
                                        </div>
                                        <div class="link-box">
                                            <a href="<?php echo $projetos->getLink(); ?>" class="link">Saiba mais</a>
                                        </div>   
                                    </section>    
                                <?php
                                }
                                ?>
                    <?php   } ?>

                <?php   } ?>
                    
                   
                 
                </main>

            <footer class="footer-todo">

                <div class="p-footer">
                    <p>Created by Luiz Marques.</p> 
                </div>
                <div class="links-footer">
                <a href="https://github.com/luizfsmarques" target="blank">
                    <img src="/public/img/github.png" alt="Link para site github">
                    
                </a>
                <a href="https://www.linkedin.com/in/luiz-fernando-serra-marques-50b21417b/" target="blank">
                    <img src="/public/img/linkedin.png" alt="Link para site linkedin">
                   
                </a>
            </div>     

            </footer>

        </div>

         <script src="/public/js/mostraMenu.js"></script>


    </body>
</html>